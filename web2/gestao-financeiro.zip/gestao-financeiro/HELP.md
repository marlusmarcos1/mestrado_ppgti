Justificativa da escolha do domínio:
Como tenho uma plailha com as contas e pagamentos com valores e etc
Pensei em modelar esse domínio que hoje uso para controle financeiro